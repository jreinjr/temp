put 'activity_report/save_settings' => 'activity_report#save_settings'
